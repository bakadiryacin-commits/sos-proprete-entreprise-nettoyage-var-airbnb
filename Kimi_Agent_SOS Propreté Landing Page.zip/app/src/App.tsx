import Header from './sections/Header';
import Hero from './sections/Hero';
import Services from './sections/Services';
import Avantages from './sections/Avantages';
import Processus from './sections/Processus';
import Temoignages from './sections/Temoignages';
import Contact from './sections/Contact';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <Services />
        <Avantages />
        <Processus />
        <Temoignages />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
