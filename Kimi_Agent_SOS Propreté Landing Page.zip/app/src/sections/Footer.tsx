import { Sparkles, Mail, Phone, MapPin, Instagram, Facebook } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    services: [
      { label: 'Nettoyage complet', href: '#services' },
      { label: 'Préparation des lits', href: '#services' },
      { label: 'Entretien textile', href: '#services' },
      { label: 'Désinfection', href: '#services' },
    ],
    company: [
      { label: 'À propos', href: '#avantages' },
      { label: 'Notre processus', href: '#processus' },
      { label: 'Témoignages', href: '#temoignages' },
      { label: 'Contact', href: '#contact' },
    ],
    zones: [
      'Toulon',
      'Hyères',
      'Saint-Tropez',
      'Fréjus',
      'Saint-Raphaël',
      'Brignoles',
      'Draguignan',
    ],
  };

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#141414] text-white">
      {/* Main Footer */}
      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20 py-16 lg:py-20">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <a href="#hero" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">
                SOS <span className="text-[#522EF5]">propreté</span>
              </span>
            </a>
            <p className="text-white/60 mb-6 leading-relaxed">
              Service de nettoyage professionnel dédié aux conciergeries Airbnb
              dans le Var. Qualité hôtelière, réactivité garantie.
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#522EF5] transition-colors duration-300"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#522EF5] transition-colors duration-300"
              >
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Nos services</h4>
            <ul className="space-y-3">
              {footerLinks.services.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection(link.href);
                    }}
                    className="text-white/60 hover:text-[#C2FFEC] transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Liens utiles</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection(link.href);
                    }}
                    className="text-white/60 hover:text-[#C2FFEC] transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Zones */}
          <div>
            <h4 className="font-semibold text-lg mb-6">Contact</h4>
            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-[#522EF5]" />
                <span className="text-white/60">06 XX XX XX XX</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-[#522EF5]" />
                <span className="text-white/60">contact@sosproprete.fr</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#522EF5] flex-shrink-0 mt-0.5" />
                <span className="text-white/60">Intervention dans tout le Var (83)</span>
              </li>
            </ul>

            <h4 className="font-semibold text-lg mb-4">Zones couvertes</h4>
            <div className="flex flex-wrap gap-2">
              {footerLinks.zones.map((zone, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-white/10 rounded-full text-xs text-white/70"
                >
                  {zone}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20 py-6">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-white/50 text-sm">
              {currentYear} SOS propreté. Tous droits réservés.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="text-white/50 hover:text-white transition-colors">
                Mentions légales
              </a>
              <a href="#" className="text-white/50 hover:text-white transition-colors">
                Politique de confidentialité
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
