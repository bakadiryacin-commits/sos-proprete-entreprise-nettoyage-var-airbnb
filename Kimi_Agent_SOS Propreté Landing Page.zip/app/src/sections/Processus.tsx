import { Calendar, ClipboardCheck, Sparkles, FileCheck } from 'lucide-react';

const Processus = () => {
  const steps = [
    {
      number: '01',
      icon: Calendar,
      title: 'Réservation',
      description:
        'Réservez votre créneau en ligne ou par téléphone. Nous nous adaptons à votre planning de locations.',
    },
    {
      number: '02',
      icon: ClipboardCheck,
      title: 'Briefing',
      description:
        'Nous récupérons vos consignes spécifiques et les particularités de chaque logement.',
    },
    {
      number: '03',
      icon: Sparkles,
      title: 'Intervention',
      description:
        'Notre équipe professionnelle intervient dans les délais impartis avec rigueur et précision.',
    },
    {
      number: '04',
      icon: FileCheck,
      title: 'Validation',
      description:
        'Recevez un compte-rendu détaillé avec photos pour confirmer la qualité de la prestation.',
    },
  ];

  return (
    <section id="processus" className="py-20 lg:py-32 bg-white relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#C2FFEC]/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-[#522EF5]/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20 relative">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-[#C2FFEC] text-[#141414] px-4 py-2 rounded-full text-sm font-medium mb-6">
            <ClipboardCheck className="w-4 h-4" />
            Notre processus
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#141414] mb-6">
            Comment ça <span className="text-[#522EF5]">marche</span> ?
          </h2>
          <p className="text-lg text-[#141414]/70">
            Un processus simple et efficace pour vous permettre de vous
            concentrer sur l\'essentiel : l\'accueil de vos hôtes.
          </p>
        </div>

        {/* Steps */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-16 left-full w-full h-0.5 bg-gradient-to-r from-[#522EF5]/30 to-transparent z-0" />
              )}

              <div className="relative z-10 bg-[#F5F6F7] rounded-2xl p-6 lg:p-8 h-full hover:shadow-lg transition-shadow duration-300 group">
                {/* Step Number */}
                <div className="absolute -top-3 -right-3 w-10 h-10 rounded-full gradient-primary flex items-center justify-center text-white font-bold text-sm shadow-glow">
                  {step.number}
                </div>

                {/* Icon */}
                <div className="w-14 h-14 rounded-2xl bg-white flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-sm">
                  <step.icon className="w-7 h-7 text-[#522EF5]" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-[#141414] mb-3">
                  {step.title}
                </h3>
                <p className="text-[#141414]/70 leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-3 bg-[#141414] text-white px-6 py-4 rounded-2xl">
            <div className="w-10 h-10 rounded-full bg-[#522EF5] flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="text-left">
              <div className="font-semibold">Première réservation ?</div>
              <div className="text-sm text-white/70">
                Bénéficiez de -10% sur votre premier nettoyage
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Processus;
