import { Card, CardContent } from '@/components/ui/card';
import { Star, Quote, MessageCircle } from 'lucide-react';

const Temoignages = () => {
  const testimonials = [
    {
      name: 'Marie L.',
      role: 'Concierge à Toulon',
      content:
        'SOS propreté a transformé mon activité. Mes hôtes sont toujours impressionnés par la propreté impeccable. Leur réactivité est un vrai plus dans ce métier.',
      rating: 5,
      avatar: 'ML',
    },
    {
      name: 'Pierre D.',
      role: 'Propriétaire à Hyères',
      content:
        'Je gère 8 locations et SOS propreté est devenu mon partenaire indispensable. Qualité constante, équipe professionnelle, je recommande les yeux fermés.',
      rating: 5,
      avatar: 'PD',
    },
    {
      name: 'Sophie M.',
      role: 'Conciergerie Saint-Tropez',
      content:
        'Excellente prestation à chaque intervention. Le reporting avec photos me rassure et mes clients sont satisfaits. Un service haut de gamme !',
      rating: 5,
      avatar: 'SM',
    },
  ];

  return (
    <section id="temoignages" className="py-20 lg:py-32 bg-[#141414] relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-[#522EF5]/20 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-[#C2FFEC]/10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />

      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20 relative">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-[#522EF5]/20 text-[#C2FFEC] px-4 py-2 rounded-full text-sm font-medium mb-6">
            <MessageCircle className="w-4 h-4" />
            Témoignages
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Ce que disent nos <span className="text-[#C2FFEC]">clients</span>
          </h2>
          <p className="text-lg text-white/70">
            Des conciergeries et propriétaires satisfaits qui nous font
            confiance au quotidien.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="bg-white/5 backdrop-blur-sm border-0 hover:bg-white/10 transition-colors duration-300"
            >
              <CardContent className="p-6 lg:p-8">
                {/* Quote Icon */}
                <Quote className="w-10 h-10 text-[#522EF5] mb-6 opacity-50" />

                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-5 h-5 fill-[#C2FFEC] text-[#C2FFEC]"
                    />
                  ))}
                </div>

                {/* Content */}
                <p className="text-white/90 leading-relaxed mb-6">
                  "{testimonial.content}"
                </p>

                {/* Author */}
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-white font-semibold">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <div className="font-semibold text-white">
                      {testimonial.name}
                    </div>
                    <div className="text-sm text-white/60">
                      {testimonial.role}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats Row */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-[#C2FFEC] mb-2">98%</div>
            <div className="text-white/60">clients satisfaits</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-[#C2FFEC] mb-2">500+</div>
            <div className="text-white/60">nettoyages/mois</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-[#C2FFEC] mb-2">4.9/5</div>
            <div className="text-white/60">note moyenne</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-[#C2FFEC] mb-2">3 ans</div>
            <div className="text-white/60">d\'expérience</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Temoignages;
