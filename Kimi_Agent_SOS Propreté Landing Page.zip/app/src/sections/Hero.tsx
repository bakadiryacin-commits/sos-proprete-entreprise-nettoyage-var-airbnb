import { Button } from '@/components/ui/button';
import { ArrowRight, Check, Star } from 'lucide-react';

const Hero = () => {
  const scrollToContact = () => {
    const element = document.querySelector('#contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const benefits = [
    'Nettoyage professionnel garanti',
    'Disponible 7j/7 dans le VAR',
    'Réponse sous 2h',
  ];

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center pt-20 overflow-hidden"
    >
      {/* Background Elements */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 right-0 w-[600px] h-[600px] bg-[#C2FFEC]/30 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-[#522EF5]/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-br from-[#C2FFEC]/20 to-transparent rounded-full blur-3xl" />
      </div>

      {/* Grid Pattern */}
      <div
        className="absolute inset-0 -z-10 opacity-[0.03]"
        style={{
          backgroundImage: `linear-gradient(#141414 1px, transparent 1px), linear-gradient(90deg, #141414 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20 py-12 lg:py-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Content */}
          <div className="space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-[#C2FFEC] text-[#141414] px-4 py-2 rounded-full text-sm font-medium">
              <Star className="w-4 h-4 fill-[#522EF5] text-[#522EF5]" />
              Spécialiste conciergerie Airbnb dans le VAR
            </div>

            {/* Headline */}
            <div className="space-y-4">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-[#141414] leading-tight">
                Vos locations{' '}
                <span className="relative">
                  <span className="relative z-10">impeccables</span>
                  <span className="absolute bottom-2 left-0 right-0 h-3 bg-[#C2FFEC] -z-0" />
                </span>
                ,<br />
                vos avis{' '}
                <span className="text-[#522EF5]">éclatants</span>
              </h1>
              <p className="text-lg sm:text-xl text-[#141414]/70 max-w-xl leading-relaxed">
                Service de nettoyage professionnel dédié aux conciergeries
                Airbnb. Qualité hôtelière, réactivité garantie, dans tout le
                Var.
              </p>
            </div>

            {/* Benefits */}
            <div className="flex flex-wrap gap-4">
              {benefits.map((benefit, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 text-sm text-[#141414]/80"
                >
                  <div className="w-5 h-5 rounded-full bg-[#C2FFEC] flex items-center justify-center">
                    <Check className="w-3 h-3 text-[#141414]" />
                  </div>
                  {benefit}
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={scrollToContact}
                size="lg"
                className="gradient-primary text-white font-semibold px-8 py-6 rounded-full text-base hover:shadow-glow transition-all duration-300 hover:scale-105 group"
              >
                Obtenir notre grille tarifaire
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => {
                  const element = document.querySelector('#services');
                  if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="border-2 border-[#141414]/20 text-[#141414] font-semibold px-8 py-6 rounded-full text-base hover:bg-[#141414] hover:text-white transition-all duration-300"
              >
                Découvrir nos services
              </Button>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-4">
              <div>
                <div className="text-3xl font-bold text-[#522EF5]">500+</div>
                <div className="text-sm text-[#141414]/60">
                  locations nettoyées
                </div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#522EF5]">4.9/5</div>
                <div className="text-sm text-[#141414]/60">
                  satisfaction clients
                </div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#522EF5]">2h</div>
                <div className="text-sm text-[#141414]/60">
                  temps de réponse
                </div>
              </div>
            </div>
          </div>

          {/* Image/Visual */}
          <div className="relative hidden lg:block">
            <div className="relative">
              {/* Main Image Container */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                <div className="aspect-[4/3] bg-gradient-to-br from-[#F5F6F7] to-white flex items-center justify-center">
                  <div className="text-center p-8">
                    <div className="w-32 h-32 mx-auto mb-6 rounded-2xl gradient-primary flex items-center justify-center shadow-glow">
                      <svg
                        className="w-16 h-16 text-white"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={1.5}
                          d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"
                        />
                      </svg>
                    </div>
                    <h3 className="text-2xl font-bold text-[#141414] mb-2">
                      SOS propreté
                    </h3>
                    <p className="text-[#141414]/60">
                      Votre partenaire confiance
                    </p>
                  </div>
                </div>
              </div>

              {/* Floating Card 1 */}
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-4 flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#C2FFEC] flex items-center justify-center">
                  <Check className="w-6 h-6 text-[#141414]" />
                </div>
                <div>
                  <div className="font-semibold text-[#141414]">Qualité</div>
                  <div className="text-sm text-[#141414]/60">Garantie</div>
                </div>
              </div>

              {/* Floating Card 2 */}
              <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-xl p-4">
                <div className="flex items-center gap-1 mb-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-[#522EF5] text-[#522EF5]"
                    />
                  ))}
                </div>
                <div className="text-sm text-[#141414]/60">
                  Note moyenne clients
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
