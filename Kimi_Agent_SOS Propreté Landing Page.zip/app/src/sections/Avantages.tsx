import { Check, Clock, MapPin, Shield, Award, Headphones } from 'lucide-react';

const Avantages = () => {
  const avantages = [
    {
      icon: Clock,
      title: 'Réactivité garantie',
      description:
        'Réponse sous 2h et intervention possible sous 24h. Nous nous adaptons à vos délais de check-in/check-out.',
    },
    {
      icon: MapPin,
      title: 'Couverture totale du VAR',
      description:
        'Intervention dans tout le département : Toulon, Hyères, Saint-Tropez, Fréjus, Saint-Raphaël et environs.',
    },
    {
      icon: Shield,
      title: 'Assurance professionnelle',
      description:
        'Entreprise assurée et responsable. Vos biens sont protégés pendant chaque intervention.',
    },
    {
      icon: Award,
      title: 'Qualité hôtelière',
      description:
        'Standards de propreté inspirés de l\'hôtellerie haut de gamme pour des avis 5 étoiles.',
    },
    {
      icon: Headphones,
      title: 'Service client dédié',
      description:
        'Un interlocuteur unique pour suivre vos interventions et répondre à vos questions.',
    },
    {
      icon: Check,
      title: 'Satisfaction garantie',
      description:
        'En cas d\'insatisfaction, nous revenons gratuitement pour parfaire notre prestation.',
    },
  ];

  return (
    <section id="avantages" className="py-20 lg:py-32 bg-[#F5F6F7]">
      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 bg-white text-[#141414] px-4 py-2 rounded-full text-sm font-medium shadow-sm">
              <Award className="w-4 h-4 text-[#522EF5]" />
              Pourquoi nous choisir
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#141414] leading-tight">
              La propreté qui fait la{' '}
              <span className="text-[#522EF5]">différence</span>
            </h2>

            <p className="text-lg text-[#141414]/70 leading-relaxed">
              Les voyageurs remarquent la propreté dès leur arrivée. Avec SOS
              propreté, assurez des avis élogieux et un taux de remplissage
              optimal pour vos locations saisonnières.
            </p>

            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-[#C2FFEC] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check className="w-4 h-4 text-[#141414]" />
                </div>
                <div>
                  <div className="font-semibold text-[#141414]">
                    Équipe formée et expérimentée
                  </div>
                  <div className="text-[#141414]/60">
                    Nos agents sont spécialement formés aux exigences des
                    locations courtes durées.
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-[#C2FFEC] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check className="w-4 h-4 text-[#141414]" />
                </div>
                <div>
                  <div className="font-semibold text-[#141414]">
                    Produits éco-responsables
                  </div>
                  <div className="text-[#141414]/60">
                    Nous utilisons des produits respectueux de l\'environnement
                    et de la santé.
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-6 h-6 rounded-full bg-[#C2FFEC] flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Check className="w-4 h-4 text-[#141414]" />
                </div>
                <div>
                  <div className="font-semibold text-[#141414]">
                    Reporting détaillé
                  </div>
                  <div className="text-[#141414]/60">
                    Photos et compte-rendu après chaque intervention pour votre
                    tranquillité.
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {avantages.map((avantage, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-[#522EF5]/10 flex items-center justify-center mb-4">
                  <avantage.icon className="w-6 h-6 text-[#522EF5]" />
                </div>
                <h3 className="text-lg font-bold text-[#141414] mb-2">
                  {avantage.title}
                </h3>
                <p className="text-sm text-[#141414]/70 leading-relaxed">
                  {avantage.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Avantages;
