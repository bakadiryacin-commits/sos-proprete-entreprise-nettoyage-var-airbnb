import { Card, CardContent } from '@/components/ui/card';
import {
  Sparkles,
  BedDouble,
  Sofa,
  UtensilsCrossed,
  Wind,
  Droplets,
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Sparkles,
      title: 'Nettoyage complet',
      description:
        'Nettoyage approfondi de toutes les pièces : sols, surfaces, vitres, et espaces difficiles d\'accès.',
      color: 'bg-[#522EF5]',
    },
    {
      icon: BedDouble,
      title: 'Préparation des lits',
      description:
        'Changement des draps, lits faits à l\'hôtelière, oreillers et couettes parfaitement arrangés.',
      color: 'bg-[#C2FFEC]',
      iconColor: 'text-[#141414]',
    },
    {
      icon: Sofa,
      title: 'Entretien textile',
      description:
        'Aspirage et désodorisation des canapés, fauteuils, rideaux et tapis pour un intérieur frais.',
      color: 'bg-[#522EF5]',
    },
    {
      icon: UtensilsCrossed,
      title: 'Cuisine impeccable',
      description:
        'Dégraissage des surfaces, nettoyage des appareils électroménagers et vaisselle si nécessaire.',
      color: 'bg-[#C2FFEC]',
      iconColor: 'text-[#141414]',
    },
    {
      icon: Wind,
      title: 'Désinfection',
      description:
        'Traitement désinfectant des surfaces fréquemment touchées pour la sécurité de vos hôtes.',
      color: 'bg-[#522EF5]',
    },
    {
      icon: Droplets,
      title: 'Sanitaires éclatants',
      description:
        'Nettoyage et désinfection minutieuse des salles de bain et WC avec produits professionnels.',
      color: 'bg-[#C2FFEC]',
      iconColor: 'text-[#141414]',
    },
  ];

  return (
    <section id="services" className="py-20 lg:py-32 bg-white">
      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-[#C2FFEC] text-[#141414] px-4 py-2 rounded-full text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            Nos prestations
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#141414] mb-6">
            Un service complet pour vos{' '}
            <span className="text-[#522EF5]">locations</span>
          </h2>
          <p className="text-lg text-[#141414]/70">
            Des prestations sur-mesure adaptées aux exigences des conciergeries
            Airbnb. Chaque détail compte pour offrir une expérience
            exceptionnelle à vos voyageurs.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              className="group border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-[#F5F6F7]/50"
            >
              <CardContent className="p-6 lg:p-8">
                <div
                  className={`w-14 h-14 rounded-2xl ${service.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}
                >
                  <service.icon
                    className={`w-7 h-7 ${
                      service.iconColor || 'text-white'
                    }`}
                  />
                </div>
                <h3 className="text-xl font-bold text-[#141414] mb-3">
                  {service.title}
                </h3>
                <p className="text-[#141414]/70 leading-relaxed">
                  {service.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 text-center">
          <p className="text-[#141414]/60 mb-6">
            Besoin d\'une prestation personnalisée ? Contactez-nous pour un
            devis sur-mesure.
          </p>
          <div className="inline-flex items-center gap-2 text-[#522EF5] font-medium">
            <span className="w-2 h-2 rounded-full bg-[#522EF5] animate-pulse" />
            Intervention possible sous 24h dans tout le Var
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
