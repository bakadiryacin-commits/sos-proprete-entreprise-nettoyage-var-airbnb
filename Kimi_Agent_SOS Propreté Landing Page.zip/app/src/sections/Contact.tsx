import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Mail,
  Phone,
  MapPin,
  Send,
  FileText,
  Clock,
  CheckCircle,
} from 'lucide-react';

const Contact = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    nom: '',
    email: '',
    telephone: '',
    ville: '',
    nombreLogements: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setIsSubmitted(true);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section id="contact" className="py-20 lg:py-32 bg-[#F5F6F7] relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#C2FFEC]/30 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#522EF5]/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

      <div className="w-full px-4 sm:px-6 lg:px-12 xl:px-20 relative">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 bg-white text-[#141414] px-4 py-2 rounded-full text-sm font-medium shadow-sm">
              <FileText className="w-4 h-4 text-[#522EF5]" />
              Grille tarifaire
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#141414] leading-tight">
              Obtenez votre{' '}
              <span className="text-[#522EF5]">grille tarifaire</span>{' '}
              personnalisée
            </h2>

            <p className="text-lg text-[#141414]/70 leading-relaxed">
              Remplissez le formulaire et recevez sous 24h un devis adapté à
              vos besoins. Nos tarifs sont transparents et compétitifs pour les
              professionnels de la conciergerie.
            </p>

            {/* Contact Info */}
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center shadow-sm">
                  <Phone className="w-5 h-5 text-[#522EF5]" />
                </div>
                <div>
                  <div className="text-sm text-[#141414]/60">Téléphone</div>
                  <div className="font-semibold text-[#141414]">
                    06 XX XX XX XX
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center shadow-sm">
                  <Mail className="w-5 h-5 text-[#522EF5]" />
                </div>
                <div>
                  <div className="text-sm text-[#141414]/60">Email</div>
                  <div className="font-semibold text-[#141414]">
                    contact@sosproprete.fr
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-white flex items-center justify-center shadow-sm">
                  <MapPin className="w-5 h-5 text-[#522EF5]" />
                </div>
                <div>
                  <div className="text-sm text-[#141414]/60">Zone d\'intervention</div>
                  <div className="font-semibold text-[#141414]">
                    Tout le Var (83)
                  </div>
                </div>
              </div>
            </div>

            {/* Features */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-[#C2FFEC] flex items-center justify-center flex-shrink-0">
                  <Clock className="w-5 h-5 text-[#141414]" />
                </div>
                <div>
                  <div className="font-semibold text-[#141414] mb-1">
                    Réponse rapide garantie
                  </div>
                  <div className="text-sm text-[#141414]/70">
                    Vous recevrez votre devis personnalisé sous 24h ouvrées.
                    Pour les demandes urgentes, contactez-nous directement par
                    téléphone.
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="bg-white rounded-3xl shadow-xl p-6 lg:p-10">
            {isSubmitted ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 rounded-full bg-[#C2FFEC] flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-10 h-10 text-[#141414]" />
                </div>
                <h3 className="text-2xl font-bold text-[#141414] mb-4">
                  Demande envoyée !
                </h3>
                <p className="text-[#141414]/70 mb-6">
                  Nous avons bien reçu votre demande. Vous recevrez votre grille
                  tarifaire sous 24h.
                </p>
                <Button
                  onClick={() => setIsSubmitted(false)}
                  variant="outline"
                  className="border-[#141414]/20"
                >
                  Envoyer une nouvelle demande
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="nom" className="text-[#141414]">
                      Nom complet *
                    </Label>
                    <Input
                      id="nom"
                      name="nom"
                      placeholder="Votre nom"
                      required
                      value={formData.nom}
                      onChange={handleChange}
                      className="h-12 border-[#141414]/10 focus:border-[#522EF5] focus:ring-[#522EF5]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-[#141414]">
                      Email *
                    </Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="votre@email.com"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="h-12 border-[#141414]/10 focus:border-[#522EF5] focus:ring-[#522EF5]"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="telephone" className="text-[#141414]">
                      Téléphone
                    </Label>
                    <Input
                      id="telephone"
                      name="telephone"
                      type="tel"
                      placeholder="06 XX XX XX XX"
                      value={formData.telephone}
                      onChange={handleChange}
                      className="h-12 border-[#141414]/10 focus:border-[#522EF5] focus:ring-[#522EF5]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ville" className="text-[#141414]">
                      Ville d\'intervention *
                    </Label>
                    <Input
                      id="ville"
                      name="ville"
                      placeholder="Ex: Toulon"
                      required
                      value={formData.ville}
                      onChange={handleChange}
                      className="h-12 border-[#141414]/10 focus:border-[#522EF5] focus:ring-[#522EF5]"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="nombreLogements" className="text-[#141414]">
                    Nombre de logements à gérer
                  </Label>
                  <Select
                    value={formData.nombreLogements}
                    onValueChange={(value) =>
                      setFormData({ ...formData, nombreLogements: value })
                    }
                  >
                    <SelectTrigger className="h-12 border-[#141414]/10 focus:border-[#522EF5] focus:ring-[#522EF5]">
                      <SelectValue placeholder="Sélectionnez" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-3">1 à 3 logements</SelectItem>
                      <SelectItem value="4-10">4 à 10 logements</SelectItem>
                      <SelectItem value="11-20">11 à 20 logements</SelectItem>
                      <SelectItem value="20+">Plus de 20 logements</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message" className="text-[#141414]">
                    Message (optionnel)
                  </Label>
                  <Textarea
                    id="message"
                    name="message"
                    placeholder="Précisez vos besoins spécifiques..."
                    rows={4}
                    value={formData.message}
                    onChange={handleChange}
                    className="border-[#141414]/10 focus:border-[#522EF5] focus:ring-[#522EF5] resize-none"
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full gradient-primary text-white font-semibold py-6 rounded-xl hover:shadow-glow transition-all duration-300 hover:scale-[1.02]"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Obtenir ma grille tarifaire
                </Button>

                <p className="text-xs text-center text-[#141414]/50">
                  En soumettant ce formulaire, vous acceptez d\'être contacté par
                  SOS propreté concernant votre demande.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
